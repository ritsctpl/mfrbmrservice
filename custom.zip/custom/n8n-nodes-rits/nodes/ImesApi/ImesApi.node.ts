import {
IExecuteFunctions,
  INodeType,
  INodeTypeDescription,
  INodeExecutionData,
} from 'n8n-workflow';
import axios from 'axios';

export class ImesApi implements INodeType {
  // Define the node's properties directly in the class body, adhering to INodeTypeDescription
  description: INodeTypeDescription = {
    displayName: 'iMES API Node',
    name: 'imesApiNode',
    icon: 'file:logo.png',
    group: ['transform'],
    version: 1,
    description: 'Calls an iMES API using Keycloak authentication',
    defaults: {
      name: 'iMES API',
      color: '#1A82e2',
    },
    inputs: ['main'],
    outputs: ['main'],
    credentials: [
      {
        name: 'ImesApiCredentials', // Must match the name you gave your credentials
        required: false,
      },
    ],
    properties: [
    /*
      {
        displayName: 'iMES API URL',
        name: 'imesApiUrl',
        type: 'string',
        default: '',
        required: true,
      }, */

      {
        displayName: 'iMES API URL',
        name: 'imesApiUrl',
        type: 'options',
        options: [
          {
            name: 'activityService-Retrieve',
            value: 'app/v1/activity-service/retrieve',
            description: 'ActivityService Retreieve',
          },
          {
            name: 'activityService-Top50',
            value: 'app/v1/activity-service/retrieveTop50',
            description: 'ActivityService top 50 Retreieve',
          },
          {
            name: 'startService-retrieveByPcuAndSite',
            value: 'app/v1/start-service/retrieveByPcuAndSite',
            description: 'Gets the PCU step Status',
          },
          {
            name: 'OEEServicer-AvailablityScheduler',
            value: 'app/v1/downtime-service/getAvailabilityForScheduler',
            description: 'Scheuduler for Availabilty Calculation',
          },
          {
            name: 'WorkListService-getWorklist',
            value: 'app/v1/worklist-service/getWorkList',
            description: 'Get Worklist for an Operation',
          },
          {
            name: 'StartService-start',
            value: 'app/v1/start-service/start',
            description: 'PCU Start',
          },
          {
            name: 'CompleteService-complete',
            value: 'app/v1/pcucomplete-service/complete',
            description: 'PCU Complete',
          },


          // Add more options as needed
        ],
        default: '',
        required: true,
      },
      {
        displayName: 'JSON Body',
        name: 'jsonBody',
        type: 'json',
        default: '',
        description: 'The JSON data to send in the request body',
        required: true,
      },
    ],
  };

  // The execute method is where the main logic of the node is implemented
  async execute(this: IExecuteFunctions): Promise<INodeExecutionData[][]> {
   // const keycloakUrl = this.getNodeParameter('keycloakUrl', 0) as string;
   // const realm = this.getNodeParameter('realm', 0) as string;
    //const clientId = this.getNodeParameter('clientId', 0) as string;
    //const clientSecret = this.getNodeParameter('clientSecret', 0) as string;
    //const password = this.getNodeParameter('password', 0) as string;
    //const imesApiUrl = this.getNodeParameter('imesApiUrl', 0) as string;
    const imesApiUrl = this.getNodeParameter('imesApiUrl', 0) as string;
    const jsonBody = this.getNodeParameter('jsonBody', 0); // Retrieve the JSON body input from the user


		 const credentials = await this.getCredentials('ImesApiCredentials') as {
            keycloakUrl: string;
            realm: string;
            clientId: string;
            clientSecret: string;
            imesApiHost: string;
            imesPort: string;
        };
	const imesApiUrlRelative = `http://${credentials.imesApiHost}:${credentials.imesPort}/${imesApiUrl}`;
//http://localhost:8181/realms/spring-boot-microservices-realm/protocol/openid-connect/token
    try {
      const tokenResponse = await axios.post(`${credentials.keycloakUrl}/realms/${credentials.realm}/protocol/openid-connect/token`, new URLSearchParams({
        //'client_id': clientId,
 				'grant_type': 'client_credentials',
  			'client_id': credentials.clientId,
  			//'client_id': clientId,
  			'client_secret': credentials.clientSecret
  			//'client_secret': clientSecret
      }), {
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
        },
      });

      const accessToken = tokenResponse.data.access_token;

      console.log('Token --',tokenResponse.data.access_token);

			console.log('Calling ME API---',imesApiUrlRelative);

      const response = await axios.post(imesApiUrlRelative, jsonBody, { // Pass the JSON body directly here
            headers: {
              'Authorization': `Bearer ${accessToken}`,
              'Content-Type': 'application/json',
            },
          });
     console.log('API Response:', response.data);


      // Return the response data as node output
      return [this.helpers.returnJsonArray(response.data)];
    } catch (error) {
      //throw new NodeApiError(this, error as Error);
      console.error("An error occurred:", error.message);
    }
    return [[]];
  }
}

